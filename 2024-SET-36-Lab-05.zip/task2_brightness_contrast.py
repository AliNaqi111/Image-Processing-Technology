"""Lab 5 - Histogram Processing of Images
Task 2: Brightness and contrast
Requires: pip install opencv-python numpy matplotlib scikit-image
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage import data, exposure

def show(img, title):
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
    ax[0].imshow(img, cmap='gray', vmin=0, vmax=255)
    ax[0].set_title(title); ax[0].axis('off')
    ax[1].hist(img.ravel(), bins=256, range=(0, 255))
    ax[1].set_title('Histogram'); ax[1].set_xlim(0, 255)
    ax[1].set_xlabel('Intensity'); ax[1].set_ylabel('Pixel count')
    plt.tight_layout(); plt.show()

img = data.camera()
print(img.shape, img.dtype, img.min(), img.max())
print("mean=%.1f std=%.1f" % (img.mean(), img.std()))

bright  = cv2.convertScaleAbs(img, alpha=1.0, beta=60)
dark    = cv2.convertScaleAbs(img, alpha=1.0, beta=-60)
low_con = cv2.convertScaleAbs(img, alpha=0.4, beta=50)
high    = cv2.convertScaleAbs(img, alpha=1.6, beta=-40)

show(bright,  'Brightness +60 (alpha=1.0, beta=60)')
show(dark,    'Brightness -60 (alpha=1.0, beta=-60)')
show(low_con, 'Low contrast (alpha=0.4, beta=50)')
show(high,    'High contrast (alpha=1.6, beta=-40)')

fig, ax = plt.subplots(2, 3, figsize=(12, 6))
for a, (im, t) in zip(ax.ravel(), [(img,'Original'),(bright,'Bright +60'),(dark,'Dark -60'),(low_con,'Low contrast'),(high,'High contrast')]):
    a.hist(im.ravel(), bins=256, range=(0, 255)); a.set_title(t); a.set_xlim(0, 255)
ax.ravel()[5].axis('off')
plt.tight_layout(); plt.show()

for n, im in [('original',img),('bright',bright),('dark',dark),('low',low_con),('high',high)]:
    print(f"{n:9s} mean={im.mean():6.1f} std={im.std():6.1f} min={im.min()} max={im.max()}")
