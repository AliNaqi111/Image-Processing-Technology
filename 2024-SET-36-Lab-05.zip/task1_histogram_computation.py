"""Lab 5 - Histogram Processing of Images
Task 1: Histogram computation
Requires: pip install opencv-python numpy matplotlib scikit-image
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage import data, exposure

def show(img, title):
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
    ax[0].imshow(img, cmap='gray', vmin=0, vmax=255)
    ax[0].set_title(title); ax[0].axis('off')
    ax[1].hist(img.ravel(), bins=256, range=(0, 255))
    ax[1].set_title('Histogram'); ax[1].set_xlim(0, 255)
    ax[1].set_xlabel('Intensity'); ax[1].set_ylabel('Pixel count')
    plt.tight_layout(); plt.show()

img = data.camera()
print(img.shape, img.dtype, img.min(), img.max())
print("mean=%.1f std=%.1f" % (img.mean(), img.std()))

hist_cv = cv2.calcHist([img], [0], None, [256], [0, 256])
hist_np, _ = np.histogram(img.ravel(), bins=256, range=(0, 256))
print("Both methods agree:", np.array_equal(hist_cv.ravel().astype(int), hist_np))
show(img, 'Original (camera)')
