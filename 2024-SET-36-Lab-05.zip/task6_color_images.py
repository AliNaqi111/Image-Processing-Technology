"""Lab 5 - Histogram Processing of Images
Task 6: Color images
Requires: pip install opencv-python numpy matplotlib scikit-image
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage import data, exposure

def show(img, title):
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
    ax[0].imshow(img, cmap='gray', vmin=0, vmax=255)
    ax[0].set_title(title); ax[0].axis('off')
    ax[1].hist(img.ravel(), bins=256, range=(0, 255))
    ax[1].set_title('Histogram'); ax[1].set_xlim(0, 255)
    ax[1].set_xlabel('Intensity'); ax[1].set_ylabel('Pixel count')
    plt.tight_layout(); plt.show()

img = data.camera()
print(img.shape, img.dtype, img.min(), img.max())
print("mean=%.1f std=%.1f" % (img.mean(), img.std()))

rgb = data.astronaut()
fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
ax[0].imshow(rgb); ax[0].axis('off'); ax[0].set_title('Original')
for i, c in enumerate('rgb'):
    ax[1].plot(cv2.calcHist([rgb], [i], None, [256], [0, 256]), color=c)
ax[1].set_title('RGB channel histograms'); ax[1].set_xlim(0, 255)
plt.tight_layout(); plt.show()

# (a) equalize R, G, B separately
rgb_ch = np.dstack([cv2.equalizeHist(np.ascontiguousarray(rgb[:, :, i])) for i in range(3)])
# (b) equalize only Y
ycrcb = cv2.cvtColor(rgb, cv2.COLOR_RGB2YCrCb)
ycrcb[:, :, 0] = cv2.equalizeHist(ycrcb[:, :, 0])
rgb_y = cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2RGB)

fig, ax = plt.subplots(1, 3, figsize=(15, 5))
for a, (im, t) in zip(ax, [(rgb,'Original'),(rgb_ch,'Per-channel R,G,B'),(rgb_y,'Y-channel only')]):
    a.imshow(im); a.set_title(t); a.axis('off')
plt.tight_layout(); plt.show()

fig, ax = plt.subplots(1, 3, figsize=(15, 3.5))
for a, (im, t) in zip(ax, [(rgb,'Original'),(rgb_ch,'Per-channel'),(rgb_y,'Y-channel only')]):
    for i, c in enumerate('rgb'):
        a.plot(cv2.calcHist([np.ascontiguousarray(im)], [i], None, [256], [0, 256]), color=c)
    a.set_title(t + ' histograms'); a.set_xlim(0, 255)
plt.tight_layout(); plt.show()

# how much did the colour (chroma) change?
cr0 = cv2.cvtColor(rgb, cv2.COLOR_RGB2YCrCb)[:, :, 1:].astype(float)
for n, im in [('per-channel', rgb_ch), ('Y-only', rgb_y)]:
    c = cv2.cvtColor(im, cv2.COLOR_RGB2YCrCb)[:, :, 1:].astype(float)
    print(f"chroma mean abs change ({n}): {np.abs(c - cr0).mean():.2f}")
