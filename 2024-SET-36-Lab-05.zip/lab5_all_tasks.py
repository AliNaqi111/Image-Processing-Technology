"""Lab 5 - Histogram Processing of Images (all tasks)
Requires: pip install opencv-python numpy matplotlib scikit-image
"""
import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage import data, exposure

def show(img, title):
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
    ax[0].imshow(img, cmap='gray', vmin=0, vmax=255)
    ax[0].set_title(title); ax[0].axis('off')
    ax[1].hist(img.ravel(), bins=256, range=(0, 255))
    ax[1].set_title('Histogram'); ax[1].set_xlim(0, 255)
    ax[1].set_xlabel('Intensity'); ax[1].set_ylabel('Pixel count')
    plt.tight_layout(); plt.show()

img = data.camera()
print(img.shape, img.dtype, img.min(), img.max())
print("mean=%.1f std=%.1f" % (img.mean(), img.std()))

# ======================================================================
# Task 1: Histogram computation
# ======================================================================
hist_cv = cv2.calcHist([img], [0], None, [256], [0, 256])
hist_np, _ = np.histogram(img.ravel(), bins=256, range=(0, 256))
print("Both methods agree:", np.array_equal(hist_cv.ravel().astype(int), hist_np))
show(img, 'Original (camera)')

# ======================================================================
# Task 2: Brightness and contrast
# ======================================================================
bright  = cv2.convertScaleAbs(img, alpha=1.0, beta=60)
dark    = cv2.convertScaleAbs(img, alpha=1.0, beta=-60)
low_con = cv2.convertScaleAbs(img, alpha=0.4, beta=50)
high    = cv2.convertScaleAbs(img, alpha=1.6, beta=-40)

show(bright,  'Brightness +60 (alpha=1.0, beta=60)')
show(dark,    'Brightness -60 (alpha=1.0, beta=-60)')
show(low_con, 'Low contrast (alpha=0.4, beta=50)')
show(high,    'High contrast (alpha=1.6, beta=-40)')

fig, ax = plt.subplots(2, 3, figsize=(12, 6))
for a, (im, t) in zip(ax.ravel(), [(img,'Original'),(bright,'Bright +60'),(dark,'Dark -60'),(low_con,'Low contrast'),(high,'High contrast')]):
    a.hist(im.ravel(), bins=256, range=(0, 255)); a.set_title(t); a.set_xlim(0, 255)
ax.ravel()[5].axis('off')
plt.tight_layout(); plt.show()

for n, im in [('original',img),('bright',bright),('dark',dark),('low',low_con),('high',high)]:
    print(f"{n:9s} mean={im.mean():6.1f} std={im.std():6.1f} min={im.min()} max={im.max()}")

# ======================================================================
# Task 3: Contrast stretching
# ======================================================================
def stretch(img, low_pct, high_pct):
    lo, hi = np.percentile(img, (low_pct, high_pct))
    if hi == lo:
        return img.copy()
    out = (img.astype(np.float64) - lo) * 255.0 / (hi - lo)
    return np.clip(out, 0, 255).astype(np.uint8)

s_2_98  = stretch(low_con, 2, 98)
s_0_100 = stretch(low_con, 0, 100)
show(s_2_98,  'Stretched (2, 98)')
show(s_0_100, 'Stretched (0, 100)')
for n, im in [('(2,98)', s_2_98), ('(0,100)', s_0_100)]:
    print(n, "std=%.1f black=%.2f%% white=%.2f%%" % (im.std(), (im==0).mean()*100, (im==255).mean()*100))

# ======================================================================
# Task 4: Manual equalization
# ======================================================================
def manual_eq(im):
    hist, _ = np.histogram(im.ravel(), 256, (0, 256))
    cdf = hist.cumsum()
    cdf_min = cdf[cdf > 0].min()
    N = im.size
    lut = np.round((cdf - cdf_min) / (N - cdf_min) * 255).clip(0, 255).astype(np.uint8)
    return lut[im], cdf

manual, cdf = manual_eq(low_con)
cv_eq = cv2.equalizeHist(low_con)
diff = np.abs(manual.astype(int) - cv_eq.astype(int))
print("Max absolute difference:", diff.max())
print("Pixels that differ:", (diff > 0).sum())

show(manual, 'Equalized (manual)')
show(cv_eq,  'Equalized (OpenCV)')
plt.plot(cdf / cdf.max()); plt.title('Normalized CDF of low-contrast image')
plt.xlabel('Intensity'); plt.ylabel('CDF'); plt.grid(alpha=.3); plt.show()

# ======================================================================
# Task 5: Global vs adaptive (CLAHE)
# ======================================================================
show(cv2.equalizeHist(img), 'Global equalizeHist')

combos = [(1,(8,8)),(2,(8,8)),(4,(8,8)),(1,(16,16)),(2,(16,16)),(4,(16,16))]
fig, ax = plt.subplots(2, 4, figsize=(16, 8.5))
ax[0,0].imshow(img, cmap='gray', vmin=0, vmax=255); ax[0,0].set_title('Original'); ax[0,0].axis('off')
ax[1,0].imshow(cv2.equalizeHist(img), cmap='gray', vmin=0, vmax=255); ax[1,0].set_title('Global equalizeHist'); ax[1,0].axis('off')
pos = [(0,1),(0,2),(0,3),(1,1),(1,2),(1,3)]
for (c, t), p in zip(combos, pos):
    res = cv2.createCLAHE(clipLimit=c, tileGridSize=t).apply(img)
    ax[p].imshow(res, cmap='gray', vmin=0, vmax=255)
    ax[p].set_title(f'CLAHE clip={c}, tiles={t[0]}x{t[1]}'); ax[p].axis('off')
    print(f"clip={c} tiles={t} mean={res.mean():.1f} std={res.std():.1f}")
plt.tight_layout(); plt.show()

# Noise check: zoom on the smooth sky region (top-left 128x128)
crop = (slice(0, 128), slice(0, 128))
variants = [(img,'Original'), (cv2.equalizeHist(img),'Global'),
            (cv2.createCLAHE(2.0,(8,8)).apply(img),'CLAHE clip=2, 8x8'),
            (cv2.createCLAHE(4.0,(16,16)).apply(img),'CLAHE clip=4, 16x16')]
fig, ax = plt.subplots(1, 4, figsize=(14, 3.8))
for a, (im, t) in zip(ax, variants):
    a.imshow(im[crop], cmap='gray', vmin=0, vmax=255); a.set_title(t); a.axis('off')
    print(f"{t:22s} sky std = {im[crop].std():.2f}")
plt.tight_layout(); plt.show()

# ======================================================================
# Task 6: Color images
# ======================================================================
rgb = data.astronaut()
fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
ax[0].imshow(rgb); ax[0].axis('off'); ax[0].set_title('Original')
for i, c in enumerate('rgb'):
    ax[1].plot(cv2.calcHist([rgb], [i], None, [256], [0, 256]), color=c)
ax[1].set_title('RGB channel histograms'); ax[1].set_xlim(0, 255)
plt.tight_layout(); plt.show()

# (a) equalize R, G, B separately
rgb_ch = np.dstack([cv2.equalizeHist(np.ascontiguousarray(rgb[:, :, i])) for i in range(3)])
# (b) equalize only Y
ycrcb = cv2.cvtColor(rgb, cv2.COLOR_RGB2YCrCb)
ycrcb[:, :, 0] = cv2.equalizeHist(ycrcb[:, :, 0])
rgb_y = cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2RGB)

fig, ax = plt.subplots(1, 3, figsize=(15, 5))
for a, (im, t) in zip(ax, [(rgb,'Original'),(rgb_ch,'Per-channel R,G,B'),(rgb_y,'Y-channel only')]):
    a.imshow(im); a.set_title(t); a.axis('off')
plt.tight_layout(); plt.show()

fig, ax = plt.subplots(1, 3, figsize=(15, 3.5))
for a, (im, t) in zip(ax, [(rgb,'Original'),(rgb_ch,'Per-channel'),(rgb_y,'Y-channel only')]):
    for i, c in enumerate('rgb'):
        a.plot(cv2.calcHist([np.ascontiguousarray(im)], [i], None, [256], [0, 256]), color=c)
    a.set_title(t + ' histograms'); a.set_xlim(0, 255)
plt.tight_layout(); plt.show()

# how much did the colour (chroma) change?
cr0 = cv2.cvtColor(rgb, cv2.COLOR_RGB2YCrCb)[:, :, 1:].astype(float)
for n, im in [('per-channel', rgb_ch), ('Y-only', rgb_y)]:
    c = cv2.cvtColor(im, cv2.COLOR_RGB2YCrCb)[:, :, 1:].astype(float)
    print(f"chroma mean abs change ({n}): {np.abs(c - cr0).mean():.2f}")

# ======================================================================
# Task 7 (Challenge): Histogram matching
# ======================================================================
src = data.moon()
ref = data.camera()
matched = exposure.match_histograms(src, ref).astype(np.uint8)

fig, ax = plt.subplots(2, 3, figsize=(14, 7))
for j, (im, t) in enumerate([(src,'Source (moon)'),(ref,'Reference (camera)'),(matched,'Matched result')]):
    ax[0,j].imshow(im, cmap='gray', vmin=0, vmax=255); ax[0,j].set_title(t); ax[0,j].axis('off')
    ax[1,j].hist(im.ravel(), bins=256, range=(0, 255)); ax[1,j].set_xlim(0, 255); ax[1,j].set_title('Histogram')
plt.tight_layout(); plt.show()

for im, t in [(src,'Source'),(ref,'Reference'),(matched,'Matched')]:
    h, _ = np.histogram(im.ravel(), 256, (0, 256)); plt.plot(h.cumsum()/h.sum(), label=t)
plt.legend(); plt.title('Cumulative distributions'); plt.xlabel('Intensity'); plt.grid(alpha=.3); plt.show()
for n, im in [('source',src),('reference',ref),('matched',matched)]:
    print(f"{n:9s} mean={im.mean():.1f} std={im.std():.1f}")
