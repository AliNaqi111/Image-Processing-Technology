"""Lab 5 - Histogram Processing of Images
Task 7 (Challenge): Histogram matching
Requires: pip install opencv-python numpy matplotlib scikit-image
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage import data, exposure

def show(img, title):
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
    ax[0].imshow(img, cmap='gray', vmin=0, vmax=255)
    ax[0].set_title(title); ax[0].axis('off')
    ax[1].hist(img.ravel(), bins=256, range=(0, 255))
    ax[1].set_title('Histogram'); ax[1].set_xlim(0, 255)
    ax[1].set_xlabel('Intensity'); ax[1].set_ylabel('Pixel count')
    plt.tight_layout(); plt.show()

img = data.camera()
print(img.shape, img.dtype, img.min(), img.max())
print("mean=%.1f std=%.1f" % (img.mean(), img.std()))

src = data.moon()
ref = data.camera()
matched = exposure.match_histograms(src, ref).astype(np.uint8)

fig, ax = plt.subplots(2, 3, figsize=(14, 7))
for j, (im, t) in enumerate([(src,'Source (moon)'),(ref,'Reference (camera)'),(matched,'Matched result')]):
    ax[0,j].imshow(im, cmap='gray', vmin=0, vmax=255); ax[0,j].set_title(t); ax[0,j].axis('off')
    ax[1,j].hist(im.ravel(), bins=256, range=(0, 255)); ax[1,j].set_xlim(0, 255); ax[1,j].set_title('Histogram')
plt.tight_layout(); plt.show()

for im, t in [(src,'Source'),(ref,'Reference'),(matched,'Matched')]:
    h, _ = np.histogram(im.ravel(), 256, (0, 256)); plt.plot(h.cumsum()/h.sum(), label=t)
plt.legend(); plt.title('Cumulative distributions'); plt.xlabel('Intensity'); plt.grid(alpha=.3); plt.show()
for n, im in [('source',src),('reference',ref),('matched',matched)]:
    print(f"{n:9s} mean={im.mean():.1f} std={im.std():.1f}")
