"""Lab 5 - Histogram Processing of Images
Task 3: Contrast stretching
Requires: pip install opencv-python numpy matplotlib scikit-image
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage import data, exposure

def show(img, title):
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
    ax[0].imshow(img, cmap='gray', vmin=0, vmax=255)
    ax[0].set_title(title); ax[0].axis('off')
    ax[1].hist(img.ravel(), bins=256, range=(0, 255))
    ax[1].set_title('Histogram'); ax[1].set_xlim(0, 255)
    ax[1].set_xlabel('Intensity'); ax[1].set_ylabel('Pixel count')
    plt.tight_layout(); plt.show()

img = data.camera()
print(img.shape, img.dtype, img.min(), img.max())
print("mean=%.1f std=%.1f" % (img.mean(), img.std()))

low_con = cv2.convertScaleAbs(img, alpha=0.4, beta=50)  # low-contrast image from Task 2

def stretch(img, low_pct, high_pct):
    lo, hi = np.percentile(img, (low_pct, high_pct))
    if hi == lo:
        return img.copy()
    out = (img.astype(np.float64) - lo) * 255.0 / (hi - lo)
    return np.clip(out, 0, 255).astype(np.uint8)

s_2_98  = stretch(low_con, 2, 98)
s_0_100 = stretch(low_con, 0, 100)
show(s_2_98,  'Stretched (2, 98)')
show(s_0_100, 'Stretched (0, 100)')
for n, im in [('(2,98)', s_2_98), ('(0,100)', s_0_100)]:
    print(n, "std=%.1f black=%.2f%% white=%.2f%%" % (im.std(), (im==0).mean()*100, (im==255).mean()*100))
