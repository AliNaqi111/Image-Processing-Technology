"""Lab 5 - Histogram Processing of Images
Task 5: Global vs adaptive (CLAHE)
Requires: pip install opencv-python numpy matplotlib scikit-image
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage import data, exposure

def show(img, title):
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
    ax[0].imshow(img, cmap='gray', vmin=0, vmax=255)
    ax[0].set_title(title); ax[0].axis('off')
    ax[1].hist(img.ravel(), bins=256, range=(0, 255))
    ax[1].set_title('Histogram'); ax[1].set_xlim(0, 255)
    ax[1].set_xlabel('Intensity'); ax[1].set_ylabel('Pixel count')
    plt.tight_layout(); plt.show()

img = data.camera()
print(img.shape, img.dtype, img.min(), img.max())
print("mean=%.1f std=%.1f" % (img.mean(), img.std()))

show(cv2.equalizeHist(img), 'Global equalizeHist')

combos = [(1,(8,8)),(2,(8,8)),(4,(8,8)),(1,(16,16)),(2,(16,16)),(4,(16,16))]
fig, ax = plt.subplots(2, 4, figsize=(16, 8.5))
ax[0,0].imshow(img, cmap='gray', vmin=0, vmax=255); ax[0,0].set_title('Original'); ax[0,0].axis('off')
ax[1,0].imshow(cv2.equalizeHist(img), cmap='gray', vmin=0, vmax=255); ax[1,0].set_title('Global equalizeHist'); ax[1,0].axis('off')
pos = [(0,1),(0,2),(0,3),(1,1),(1,2),(1,3)]
for (c, t), p in zip(combos, pos):
    res = cv2.createCLAHE(clipLimit=c, tileGridSize=t).apply(img)
    ax[p].imshow(res, cmap='gray', vmin=0, vmax=255)
    ax[p].set_title(f'CLAHE clip={c}, tiles={t[0]}x{t[1]}'); ax[p].axis('off')
    print(f"clip={c} tiles={t} mean={res.mean():.1f} std={res.std():.1f}")
plt.tight_layout(); plt.show()

# Noise check: zoom on the smooth sky region (top-left 128x128)
crop = (slice(0, 128), slice(0, 128))
variants = [(img,'Original'), (cv2.equalizeHist(img),'Global'),
            (cv2.createCLAHE(2.0,(8,8)).apply(img),'CLAHE clip=2, 8x8'),
            (cv2.createCLAHE(4.0,(16,16)).apply(img),'CLAHE clip=4, 16x16')]
fig, ax = plt.subplots(1, 4, figsize=(14, 3.8))
for a, (im, t) in zip(ax, variants):
    a.imshow(im[crop], cmap='gray', vmin=0, vmax=255); a.set_title(t); a.axis('off')
    print(f"{t:22s} sky std = {im[crop].std():.2f}")
plt.tight_layout(); plt.show()
