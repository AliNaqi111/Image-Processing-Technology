"""Lab 5 - Histogram Processing of Images
Task 4: Manual equalization
Requires: pip install opencv-python numpy matplotlib scikit-image
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage import data, exposure

def show(img, title):
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
    ax[0].imshow(img, cmap='gray', vmin=0, vmax=255)
    ax[0].set_title(title); ax[0].axis('off')
    ax[1].hist(img.ravel(), bins=256, range=(0, 255))
    ax[1].set_title('Histogram'); ax[1].set_xlim(0, 255)
    ax[1].set_xlabel('Intensity'); ax[1].set_ylabel('Pixel count')
    plt.tight_layout(); plt.show()

img = data.camera()
print(img.shape, img.dtype, img.min(), img.max())
print("mean=%.1f std=%.1f" % (img.mean(), img.std()))

low_con = cv2.convertScaleAbs(img, alpha=0.4, beta=50)  # low-contrast image from Task 2

def manual_eq(im):
    hist, _ = np.histogram(im.ravel(), 256, (0, 256))
    cdf = hist.cumsum()
    cdf_min = cdf[cdf > 0].min()
    N = im.size
    lut = np.round((cdf - cdf_min) / (N - cdf_min) * 255).clip(0, 255).astype(np.uint8)
    return lut[im], cdf

manual, cdf = manual_eq(low_con)
cv_eq = cv2.equalizeHist(low_con)
diff = np.abs(manual.astype(int) - cv_eq.astype(int))
print("Max absolute difference:", diff.max())
print("Pixels that differ:", (diff > 0).sum())

show(manual, 'Equalized (manual)')
show(cv_eq,  'Equalized (OpenCV)')
plt.plot(cdf / cdf.max()); plt.title('Normalized CDF of low-contrast image')
plt.xlabel('Intensity'); plt.ylabel('CDF'); plt.grid(alpha=.3); plt.show()
