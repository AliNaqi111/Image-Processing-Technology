
# Program 4: Student Marks Calculation

name = input("Enter student name: ")
roll_number = input("Enter roll number: ")

subject1 = float(input("Enter marks in Subject 1: "))
subject2 = float(input("Enter marks in Subject 2: "))
subject3 = float(input("Enter marks in Subject 3: "))

total = subject1 + subject2 + subject3
average = total / 3

print("\n--- Student Result ---")
print("Name:", name)
print("Roll Number:", roll_number)
print("Total Marks:", total)
print("Average Marks:", average)
