
# Program 2: Calculate Total Pixels

width = int(input("Enter image width in pixels: "))
height = int(input("Enter image height in pixels: "))

total_pixels = width * height

print("Total Pixels:", total_pixels)
