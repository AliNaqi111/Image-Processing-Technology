
# Program 1: Arithmetic Operations

num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))

print("Sum:", num1 + num2)
print("Difference:", num1 - num2)
print("Product:", num1 * num2)

if num2 != 0:
    print("Division:", num1 / num2)
else:
    print("Division is not possible because the second number is zero.")
