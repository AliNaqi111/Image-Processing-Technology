import cv2, numpy as np, matplotlib.pyplot as plt
from skimage import data


def threshold_both(gray):
    _, binary = cv2.threshold(gray, 128, 255, cv2.THRESH_BINARY)
    adaptive = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, 31, 5)
    return binary, adaptive


def white_percent(mask):
    return 100 * (mask == 255).mean()


if __name__ == "__main__":
    gray = cv2.cvtColor(data.astronaut(), cv2.COLOR_RGB2GRAY)
    binary, adaptive = threshold_both(gray)
    for name, res in (("Global  ", binary), ("Adaptive", adaptive)):
        print(name, ": values", np.unique(res), "| white: %.1f%%" % white_percent(res))
    fig, ax = plt.subplots(1, 2, figsize=(8, 3))
    ax[0].imshow(binary, cmap='gray');   ax[0].set_title('Global')
    ax[1].imshow(adaptive, cmap='gray'); ax[1].set_title('Adaptive')
    for a in ax: a.axis('off')
    plt.savefig('shots/fig_task4.png', dpi=110, bbox_inches='tight'); plt.show()
