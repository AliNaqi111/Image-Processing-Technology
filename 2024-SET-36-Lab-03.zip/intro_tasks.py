"""Lab 03 - Part A: Intro to Python, NumPy & OpenCV (the four practice tasks)."""
import numpy as np
import cv2


def numpy_demo(values):
    """Create an array and print it, its sum and its average."""
    numbers = np.array(values)
    print("Numbers:", numbers)
    print("Sum:", np.sum(numbers))
    print("Average:", np.mean(numbers))
    return numbers


def make_text_image(message, height, width, color_bgr, out_path):
    """Create a black image of (height, width, 3) and write text on it."""
    image = np.zeros((height, width, 3), dtype=np.uint8)
    cv2.putText(image, message, (40, height // 2), cv2.FONT_HERSHEY_SIMPLEX,
                1, color_bgr, 2)
    cv2.imwrite(out_path, image)
    return image


if __name__ == "__main__":
    print("=== Task 1: NumPy with [5, 10, 15] ===")
    numpy_demo([5, 10, 15])

    print("\nOpenCV version:", cv2.__version__)

    print("\n=== Task 2: custom message ===")
    img2 = make_text_image("Hello, I am learning IPT!", 300, 400, (255, 255, 255), "shots/raw_task2.png")
    print("Image shape:", img2.shape)

    print("\n=== Task 3: dimensions (200, 500, 3) ===")
    img3 = make_text_image("Hello OpenCV!", 200, 500, (255, 255, 255), "shots/raw_task3.png")
    print("Image shape:", img3.shape)

    print("\n=== Task 4: red text (0, 0, 255) in BGR ===")
    img4 = make_text_image("Hello OpenCV!", 300, 400, (0, 0, 255), "shots/raw_task4.png")
    print("Image shape:", img4.shape, "| text colour (B,G,R) = (0, 0, 255)")
