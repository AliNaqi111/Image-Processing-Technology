import cv2, numpy as np, matplotlib.pyplot as plt
from skimage import data


def load_image():
    """Load the built-in RGB astronaut demo image (a NumPy array)."""
    return data.astronaut()


def describe(img):
    print("Type  :", type(img))
    print("Shape :", img.shape, "-> (height, width, channels)")
    print("Dtype :", img.dtype)
    print("Min/Max pixel value:", img.min(), "/", img.max())
    print("Pixel at (0,0) [R,G,B]:", img[0, 0])


if __name__ == "__main__":
    img = load_image()
    describe(img)
    plt.imshow(img); plt.axis('off'); plt.title('Task 1: Original RGB image')
    plt.savefig('shots/fig_task1.png', dpi=110, bbox_inches='tight'); plt.show()
