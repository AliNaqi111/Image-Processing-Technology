import cv2, numpy as np, matplotlib.pyplot as plt
from skimage import data


def to_gray(img):
    return cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)


def manual_gray(img):
    """Weighted sum 0.299R + 0.587G + 0.114B."""
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    return (0.299 * r + 0.587 * g + 0.114 * b).astype(np.uint8)


if __name__ == "__main__":
    img = data.astronaut()
    gray = to_gray(img)
    print(gray.shape, gray.dtype)
    diff = np.abs(gray.astype(int) - manual_gray(img).astype(int)).max()
    print("Max diff vs manual formula:", diff)
    plt.imshow(gray, cmap='gray'); plt.axis('off'); plt.title('Task 3: Grayscale')
    plt.savefig('shots/fig_task3.png', dpi=110, bbox_inches='tight'); plt.show()
