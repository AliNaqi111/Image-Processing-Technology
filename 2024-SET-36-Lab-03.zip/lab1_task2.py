import cv2, numpy as np, matplotlib.pyplot as plt
from skimage import data


def show_channels(img):
    R, G, B = cv2.split(img)
    print("R shape:", R.shape, "| G shape:", G.shape, "| B shape:", B.shape)
    means = (R.mean(), G.mean(), B.mean())
    print("Mean intensity -> R: %.2f  G: %.2f  B: %.2f" % means)
    fig, ax = plt.subplots(1, 3, figsize=(10, 3))
    ax[0].imshow(R, cmap='Reds');   ax[0].set_title('R')
    ax[1].imshow(G, cmap='Greens'); ax[1].set_title('G')
    ax[2].imshow(B, cmap='Blues');  ax[2].set_title('B')
    for a in ax: a.axis('off')
    plt.savefig('shots/fig_task2.png', dpi=110, bbox_inches='tight'); plt.show()


if __name__ == "__main__":
    show_channels(data.astronaut())
